package com.dicoding.jetcoffee.ui.theme

import androidx.compose.ui.graphics.Color

val CoffeeBrown = Color(0xFF886345)
val LightCoffeeBrown = Color(0xFFF2DED1)
val LightGray = Color(0xFFBBBBBB)
