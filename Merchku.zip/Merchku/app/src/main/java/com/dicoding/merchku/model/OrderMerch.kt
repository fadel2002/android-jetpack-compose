package com.dicoding.merchku.model

data class OrderMerch(
    val merch: Merch,
    val count: Int
)