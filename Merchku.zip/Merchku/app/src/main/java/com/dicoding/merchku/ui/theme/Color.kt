package com.dicoding.merchku.ui.theme

import androidx.compose.ui.graphics.Color

val Teal200 = Color(0xFF03DAC5)
val Gray200 = Color(0xFFD3D4D9)
val Gray500 = Color(0xFF919297)
val Gray700 = Color(0xFF75767B)