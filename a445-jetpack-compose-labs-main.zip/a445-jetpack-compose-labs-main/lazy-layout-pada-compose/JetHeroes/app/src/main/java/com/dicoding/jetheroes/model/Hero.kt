package com.dicoding.jetheroes.model

data class Hero(
    val id: String,
    val name: String,
    val photoUrl: String
)