package com.dicoding.jetreward.ui.theme

import androidx.compose.ui.graphics.Color

val Navy200 = Color(0xFFC3DFED)
val Navy500 = Color(0xFF2D3E50)
val Navy700 = Color(0xFF152439)
val Turquoise500 = Color(0xFF11C5C6)
