package com.dicoding.merchku.model

data class Merch(
    val id: Long,
    val image: Int,
    val title: String,
    val requiredPoint: Int,
)